#!/bin/sh

python3.11 api.py

